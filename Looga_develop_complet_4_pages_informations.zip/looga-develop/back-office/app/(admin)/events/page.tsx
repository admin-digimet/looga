import { TopNav } from '@/components/layout/TopNav'
import { EventsTable } from './EventsTable'

export default function EventsPage() {
  return (
    <div className="flex flex-col h-full">
      <TopNav title="Événements" />
      <div className="flex-1 p-6 flex flex-col gap-4">
        <EventsTable />
      </div>
    </div>
  )
}
